"""Download the original COMAP archive and validate the known data bytes."""
from pathlib import Path
import hashlib
import io
import json
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
URL = 'https://www.comap.org/component/zoo/?element=979148b8-68eb-4e88-83df-a28439d5b0e5&format=raw&item_id=3304&method=download&task=callelement'
EXPECTED = 'b1788d0ea169b65629b0e9fb0f91d007507b306e404507bbf90bd5f700a3c229'


def main():
    folder = ROOT/'data/raw'; folder.mkdir(parents=True,exist_ok=True)
    with urllib.request.urlopen(URL,timeout=90) as response:
        archive = zipfile.ZipFile(io.BytesIO(response.read()))
    content = archive.read('2024_Wimbledon_featured_matches.csv')
    actual = hashlib.sha256(content).hexdigest()
    if actual != EXPECTED:
        raise ValueError(f'Official data changed: expected {EXPECTED}, got {actual}. Review before use.')
    (folder/'Wimbledon_featured_matches.csv').write_bytes(content)
    (folder/'data_dictionary.csv').write_bytes(archive.read('2024_data_dictionary.csv'))
    print(f'Official data downloaded and verified: {actual}')


if __name__ == '__main__': main()
