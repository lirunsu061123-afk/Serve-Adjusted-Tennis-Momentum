"""Build the Chinese report (Markdown, standalone HTML, and PDF) from real results.

For PDF: pass --font /path/to/CJK.ttf or use a known Windows/Linux CJK font.
The PDF uses explicit section pages, embedded CJK fonts and math rendered by
matplotlib. No network access is needed to read the standalone HTML report.
"""
from pathlib import Path
import argparse
import base64
import html
import json
import re
import sys
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import markdown
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
from reportlab.lib.utils import ImageReader

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.report_content import make_pages as make_pages_zh


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--font');parser.add_argument('--english',action='store_true');args=parser.parse_args()
    if args.english:
        from scripts.report_content_en import make_pages as make_pages_en
        make_pages = make_pages_en
    else:
        make_pages = make_pages_zh
    candidates=[args.font,'C:/Windows/Fonts/msyh.ttc','C:/Windows/Fonts/simhei.ttf',
                '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
                '/usr/share/fonts/truetype/arphic/uming.ttc']
    font=next((p for p in candidates if p and Path(p).exists()),None)
    if not font: raise RuntimeError('Install a TrueType CJK font and pass --font PATH')
    pdfmetrics.registerFont(TTFont('CJK',font,subfontIndex=0))
    pdfmetrics.registerFontFamily('CJK',normal='CJK',bold='CJK',italic='CJK',boldItalic='CJK')
    docs=ROOT/'docs'; assets=docs/'assets';assets.mkdir(parents=True,exist_ok=True)
    pages=make_pages(ROOT)
    md='\n\n<!-- pagebreak -->\n\n'.join(f'# {title}\n\n{body.strip()}' for title,body in pages)
    stem='report.en' if args.english else 'report.zh-CN'
    (docs/f'{stem}.md').write_text(md,encoding='utf-8')
    # Both formats use the same content, figures, equations and result tables.
    count=[0]
    def equation(match):
        count[0]+=1;path=assets/f'equation_{count[0]:02d}.png'
        formula=match.group(1).strip()
        fig=plt.figure(figsize=(8,.55));fig.text(.5,.5,'$'+formula+'$',ha='center',va='center',fontsize=15)
        plt.axis('off');fig.savefig(path,dpi=200,bbox_inches='tight',pad_inches=.08,transparent=False);plt.close(fig)
        return f'![Equation {count[0]}](assets/{path.name})'
    render_md=re.sub(r'\$\$(.*?)\$\$',equation,md,flags=re.S)
    html_text=markdown.markdown(render_md,extensions=['tables','fenced_code'])
    def embed(match):
        source=match.group(1);p=(docs/source).resolve()
        return 'src="data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()+'"'
    html_text=re.sub(r'src="([^"]+\.png)"',embed,html_text)
    css='''body{font-family:"Microsoft YaHei","Noto Sans CJK SC",sans-serif;max-width:950px;margin:50px auto;padding:0 28px;line-height:1.85;color:#203440}h1{font-size:27px;border-bottom:3px solid #15847e;padding-bottom:12px;margin-top:60px}h2{color:#176f79;font-size:20px}table{border-collapse:collapse;width:100%;font-size:14px;margin:22px 0}th{background:#e8f3f4}td,th{padding:9px;border:1px solid #d1dfe3;text-align:left}img{max-width:100%;display:block;margin:20px auto}code{background:#edf2f4;padding:2px 4px}a{color:#157c87}@media print{body{margin:0;max-width:none}.pagebreak{break-after:page}h1{margin-top:0}}'''
    html_text=html_text.replace('<!-- pagebreak -->','<div class="pagebreak"></div>')
    lang='en' if args.english else 'zh-CN'
    title='Serve-Adjusted Tennis Momentum' if args.english else '网球势头建模研究'
    (docs/f'{stem}.html').write_text(f'<!doctype html><html lang="{lang}"><meta charset="utf-8"><title>{title}</title><style>'+css+'</style><body>'+html_text+'</body></html>',encoding='utf-8')
    styles={
        'title':ParagraphStyle('Title',fontName='CJK',fontSize=21,leading=30,textColor=colors.HexColor('#173e53'),spaceAfter=18,wordWrap='CJK'),
        'head':ParagraphStyle('Head',fontName='CJK',fontSize=13,leading=20,textColor=colors.HexColor('#147d80'),spaceBefore=8,spaceAfter=7,wordWrap='CJK'),
        'body':ParagraphStyle('Body',fontName='CJK',fontSize=10.3,leading=17.3,spaceAfter=9,wordWrap='CJK'),
        'cell':ParagraphStyle('Cell',fontName='CJK',fontSize=8.7,leading=13,wordWrap='CJK'),
    }
    def inline(s):
        s=s.replace('₁','1').replace('₂','2')
        s=html.escape(s)
        s=re.sub(r'\*\*(.*?)\*\*',r'<b>\1</b>',s)
        s=re.sub(r'`(.*?)`',r'\1',s)
        s=re.sub(r'\[(.*?)\]\((.*?)\)',r'<link href="\2" color="#147d80">\1</link>',s)
        return s
    story=[]
    for page in render_md.split('<!-- pagebreak -->'):
        lines=page.strip().splitlines();i=0
        while i<len(lines):
            line=lines[i].strip()
            if not line:i+=1;continue
            if line.startswith('# '):story.append(Paragraph(inline(line[2:]),styles['title']));i+=1;continue
            if line.startswith('## '):story.append(Paragraph(inline(line[3:]),styles['head']));i+=1;continue
            image=re.fullmatch(r'!\[(.*?)\]\((.*?)\)',line)
            if image:
                path=(docs/image.group(2)).resolve(); iw,ih=ImageReader(str(path)).getSize()
                w=min(490,iw/1.6);h=w*ih/iw
                if h>255:w*=255/h;h=255
                story.append(Image(str(path),width=w,height=h));story.append(Spacer(1,9));i+=1;continue
            if line.startswith('|'):
                rows=[]
                while i<len(lines) and lines[i].strip().startswith('|'):
                    vals=[v.strip() for v in lines[i].strip().strip('|').split('|')]
                    if not all(re.fullmatch(r'[:\- ]+',v) for v in vals):rows.append(vals)
                    i+=1
                content=[[Paragraph(inline(v),styles['cell']) for v in row] for row in rows]
                table=Table(content,colWidths=[490/len(rows[0])]*len(rows[0]),repeatRows=1,hAlign='LEFT')
                table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e5f0f3')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f6f8fa')]),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.8,colors.HexColor('#8eafb8'))]))
                story.append(table);story.append(Spacer(1,11));continue
            para=[line];i+=1
            while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','![')):
                para.append(lines[i].strip());i+=1
            story.append(Paragraph(inline(' '.join(para)),styles['body']))
        story.append(PageBreak())
    story.pop()
    def footer(canvas,doc):
        canvas.setStrokeColor(colors.HexColor('#d3e0e4'));canvas.line(50,47,545,47)
        canvas.setFont('CJK',8);canvas.setFillColor(colors.HexColor('#6a808b'))
        canvas.drawString(50,33,'2024 MCM C | Reproducible research report | 2026-10-19' if args.english else '2024 MCM C | 可复现研究报告 | 2026-10-19')
        canvas.drawRightString(545,33,str(doc.page))
    doc=SimpleDocTemplate(str(docs/f'{stem}.pdf'),pagesize=(595.28,841.89),rightMargin=50,leftMargin=50,topMargin=48,bottomMargin=62,
                          title='Serve-Adjusted Tennis Momentum: 2024 MCM C' if args.english else '发球优势调整后的网球势头：2024 MCM C 可复现研究',author='Project contributors; AI-assisted with OpenAI Codex')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    print(f'Built {len(pages)} intended pages: Markdown, standalone HTML, PDF.')


if __name__=='__main__':main()
