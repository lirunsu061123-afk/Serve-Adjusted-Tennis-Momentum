"""English translation of the research report."""
import json
import pandas as pd

def mdtable(headers, rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+
                     ['| '+' | '.join(str(x) for x in row)+' |' for row in rows])

def make_pages(root):
    s=json.loads((root/'results/summary.json').read_text(encoding='utf-8'))
    read=lambda n: pd.read_csv(root/'results/tables'/n)
    point=read('point_metrics.csv').query("split=='test'")
    swing=read('swing_metrics.csv').query("split=='test'")
    sets=read('final_sets.csv')
    pnames={'global_serve':'Fixed serve baseline','online_serve':'Online serve baseline','score_context':'Serve + score','history':'Serve + score + history'}
    snames={'constant':'Constant probability','structural':'Structural model','enriched':'Enriched model'}
    pages=[]
    def add(t,b): pages.append((t,b))
    add('Serve-Adjusted Tennis Momentum',f'''## 2024 MCM Problem C · Reproducible research and GitHub project

**Abstract.** We operationalize momentum as an exponentially weighted deviation of recent point performance from a serve-adjusted baseline. We separate three questions: can momentum describe match flow, does it improve future prediction, and are observed runs more unusual than conditional random ordering?

The study uses COMAP's official 2023 Wimbledon men's data: **7,284 points across 31 matches**. Sixteen third-round matches are training data, eight fourth-round matches are validation data, and seven quarterfinal-to-final matches are held out for testing. Every point prediction uses information available before that point; technical histories are updated separately within each match.

An online Beta-Bernoulli serve baseline and EWMA residual produce an interpretable signed flow index. Validation selects **α = 0.20** and prior effective sample size **κ = 30**. Mean momentum across the five sets of the 2023 final is **−8.76, +5.15, +13.66, −6.74, and +1.13 percentage points**. These are retrospective descriptions, not causal evidence.

On 1,577 held-out points, the fixed serve baseline has log loss **0.6428**, while the model adding score and history has **0.6458**. The paired loss difference is **+0.00237**, with a match-cluster bootstrap 95% interval **[−0.00054, 0.00451]**; no stable gain is shown.

Across all 31 matches, 1,999 conditional permutations preserve serve positions and stratum totals. The global lag statistic gives **p = 0.405**; none of 62 match-level tests remains significant after multiplicity adjustment. This is insufficient to reject the specified random-order explanation, and does not prove that psychological momentum is absent.

The structural model for a reversal within the next ten points reaches AUC **0.6096**; adding technical variables lowers it to **0.5620**. High event prevalence makes recall and F1 easy to inflate. We recommend using the curve for review and prompts, retaining the simple probability baseline for decisions, and avoiding direct tactical automation.

**Keywords:** serve adjustment; online Bayesian updating; EWMA residual; conditional permutation; temporal holdout; negative-result reproducibility.

This is an independent post-hoc research demonstration assisted by OpenAI Codex, not an award paper or official contest submission. Report date: 2026-10-19.''')
    add('Contents and research questions','''| Page | Content |
| --- | --- |
| 1 | Summary and main findings |
| 2 | Contents and research questions |
| 3–4 | Data audit, assumptions, and information timing |
| 5–6 | Online serve baseline and momentum measure |
| 7–8 | Randomness test and point prediction |
| 9 | Reversal definition and prediction |
| 10–11 | Point and randomness results |
| 12–13 | Final-match case study and cross-match test |
| 14–15 | Reversal results and sensitivity |
| 16–17 | Limits, transfer, and coaching memo |
| 18–19 | Reproduction, quality control, references |
| 20 | AI-use appendix |

## Problem translation

Following the official statement [1], the study addresses flow measurement, randomness, reversal prediction, cross-match testing, and coaching advice. We do not equate a run of points with momentum before removing the known contribution of serving and observed baseline ability.

**Task 1 — description.** Produce a signed index after each point: positive means player 1 is above baseline and negative means player 2 is favored.

**Task 2 — test.** Conditional on each player's serving ability and the realized serve sequence, is the observed ordering unusual?

**Task 3 — prediction.** Predict the current point before it starts; after it ends, predict a state reversal over a fixed future window. These information times remain separate.

**Task 4 — application.** Evaluate on held-out rounds, convert supported observations into coaching advice, and state what the data cannot establish.''')
    add('Data source and quality audit',f'''The data come directly from COMAP's official resource page [2]. No synthetic match data or other teams' solutions are used. The archive contains the point table and data dictionary; the original table has 46 columns and derived model features are separate.

{mdtable(['Split','Rounds','Matches','Points'],[['Train','3',16,3788],['Validation','4',8,1919],['Test','5–7',7,1577],['Total','3–7',31,7284]])}

**Identity and order.** `(match_id, point_no)` is unique; in the actual file, point_no runs continuously from 1 to the full-match point count. Although the dictionary describes an in-game index, the supplied data do not reset it each game. The program preserves the data and asserts continuity.

**Completeness.** Key fields and all statistics used by the model are complete. `speed_mph` is missing in 752 rows (10.32%), `return_depth` in 1,309 (17.97%), and serve width and depth each in 54 (0.74%). These fields are excluded rather than imputed, and all 7,284 valid rows are retained.

**Field timing.** Cumulative points won already include the current point and cannot predict it; game_victor and set_victor are post-point outcomes. They are used only for audits or summaries. Serve number is not known before the first serve and is excluded from point prediction.

Training serve-win rate is **66.6315%**; the all-data descriptive rate is **67.3119%**. Only the former enters estimation. The official file hash and download instructions are in `data/raw/README.md`; raw third-party data are excluded from the release archive.''')
    add('Assumptions, notation, and information timing','''## Modeling assumptions

Point order and server identities are reliable. Serving is treated as the main structural advantage; each player's current-match serving ability is estimated with shrinkage. “Momentum” is first defined as a statistical index, not assumed to be an independently proven psychological force.

The design evaluates later rounds of this Wimbledon event, not new players or other surfaces. Score, technical statistics, and outcomes may share latent causes such as ability and fatigue; regression coefficients are associative, not causal.

| Symbol | Meaning |
| --- | --- |
| y_t | 1 when player 1 wins point t, otherwise 0 |
| s_t | Server identity, 1 or 2 |
| q, κ | Training serve rate and prior effective sample size |
| p_t, r_t | Pre-point baseline probability and residual |
| m_t, α | Post-point momentum and smoothing coefficient |
| z_t, δ | Hysteresis state and threshold |
| H, R_t | Future window length and reversal label |

## The timeline is the leakage rule

**Before point t:** server, set/game score, within-game score, and break-point status are available; only results and lagged technical statistics from points before t may be used.

**After point t:** y_t and point statistics become available, serve posterior and momentum are updated, and the future reversal prediction is made for t+1 through t+H.

**After the match:** set summaries, permutation tests, and realized reversal labels are computed for evaluation only and never fed back into prediction. Each match starts from the common prior.''')
    add('Model 1: online serve baseline',r'''A fixed serve rate assigns player 1 probability q and player 2 probability 1−q. To allow different serving ability, each player receives an independent Beta-Bernoulli model.

$$ \theta_j\sim\mathrm{Beta}(\kappa q,\kappa(1-q)) $$

If player j has served n_j previous points and won w_j of them, the pre-point posterior mean is

$$ \widehat{\theta}_{j,t}=\frac{\kappa q+w_{j,<t}}{\kappa+n_{j,<t}} $$

For player 1 serving, p_t is that posterior mean; for player 2 serving, p_t is one minus player 2's posterior. No current-point outcome updates the posterior before prediction.

κ expresses trust in the population serve rate. With κ=30, a player who has won 7 of 10 serves is estimated as `(30×0.6663+7)/40≈0.6747`, rather than as 0.70. Small κ adapts faster but is noisier.

For training features, each match's overall q is estimated from the other 15 training matches. Validation and test use one q estimated from all 16 training matches. Online posteriors use only points already played in the current match and never carry across matches.

The baseline absorbs slow ability differences; momentum describes faster deviations above it. This decomposition is not uniquely identified in small samples, so α and κ are examined by sensitivity analysis. Complexity is kept only if held-out scores improve.''')
    add('Model 2: momentum curve and hysteresis',r'''Let actual performance minus the pre-point baseline be the residual, and update it with exponential decay. EWMA gives more weight to recent observations [3].

$$ r_t=y_t-p_t,\qquad m_t=(1-\alpha)m_{t-1}+\alpha r_t,\quad m_0=0 $$

$$ m_t=\alpha\sum_{i=1}^{t}(1-\alpha)^{t-i}r_i $$

The figures show 100m_t. A value of +12 means that recent weighted performance is approximately 12 percentage points above the baseline; it is not a 12-point increase in next-point win probability or match-win probability.

Under a fixed correct baseline and independent Bernoulli outcomes, the steady-state variance is approximately

$$ \mathrm{Var}(m_t)\approx\frac{\alpha}{2-\alpha}p(1-p) $$

This is a scale calculation, not the significance rule used here. Since p_t updates and tennis scores are dependent, the study uses conditional permutation rather than independent normal control limits.

α=0.20 has a half-life of about 3.11 points; α=0.10 and 0.05 have half-lives of about 6.58 and 13.51. A hysteresis state is +1 above +δ, −1 below −δ, and otherwise retains its previous state. Only a switch from an established state to the opposite state counts as a reversal. The main threshold is δ=0.08; δ=0.05 and 0.12 are sensitivity checks.''')
    add('Model 3: conditional randomness test',r'''**Null hypothesis.** Given the realized serve locations and each server stratum's total number of player-1 wins, the win order is exchangeable within each serve stratum. This allows unequal ability and a server advantage, but not systematic time variation within a stratum.

For each match, compute post-match stratum means and centered residuals. These are used only for diagnostics:

$$ e_t=y_t-\overline{y}_{s_t},\qquad T_1=\frac{\sum_{t=2}^{n}e_te_{t-1}}{\sum_{t=1}^{n}e_t^2} $$

$$ T_2=\frac{1}{\sqrt{n}}\max_{1\leq k\leq n}\left|\sum_{t=1}^{k}e_t\right| $$

T1 captures adjacent dependence; T2 captures cumulative long-run departure. For each permutation, wins are independently shuffled among the original positions for server 1 and server 2, preserving serve locations and stratum totals.

$$ p_{\rm MC}=\frac{1+\sum_{b=1}^{B}\mathbf{1}(T_b\geq T_{\rm obs})}{B+1} $$

The main experiment uses B=1,999 and seed 20241019. The two statistics across 31 matches produce 62 tests; Benjamini–Hochberg adjustment is applied jointly. A global statistic averages the 31 T1 values under the same joint permutation. The test conditions on the realized serve path and match length; it is not a complete simulator of tennis scoring. A rejection could reflect fatigue, injury, or tactics rather than psychology; a non-rejection may reflect low power or an insensitive statistic.''')
    add('Model 4: point-probability prediction',r'''The model adds a regularized correction to the online baseline log odds, forcing comparison with a transparent benchmark.

$$ \operatorname{logit}(\widehat{p}_t)=\operatorname{logit}(p_t)+\beta_0+\boldsymbol{\beta}^\top\widetilde{\boldsymbol{x}}_t $$

The score model uses server sign, set difference, game difference, within-game score difference, and break-point difference. Ordinary scores map 0/15/30/40/AD to 0/1/2/3/4; tiebreak scores retain their integer values and the difference is clipped to ±4.

The history model adds lagged EWMA errors, winners, running-distance difference, recent rally count, server alignment, and elapsed points. Every technical statistic is lagged and updated with smoothing 0.10.

$$ L(\beta)=-\frac{1}{N}\sum_{t=1}^{N}\left[y_t\log\widehat{p}_t+(1-y_t)\log(1-\widehat{p}_t)\right]+\frac{\lambda}{2}\|\beta\|_2^2 $$

Features are standardized on training data only; λ=0.01 and the intercept is unpenalized. Nine (α,κ) pairs are selected by validation log loss and then frozen. Log loss is primary, with Brier score and AUC as secondary measures. A 3,000-replicate match-cluster bootstrap estimates paired test loss differences.''')
    add('Model 5: future reversal prediction',r'''After point t, define whether the hysteresis state switches to the opposite state within the next H=10 points:

$$ R_t=\mathbf{1}\!\left(\exists u\in\{t+1,\ldots,t+H\}:z_{u-1}z_u=-1\right) $$

Incomplete tail windows and points before a state is established are excluded, rather than treated as negative examples. Adjacent windows overlap, so they are windows rather than independent events.

The constant baseline outputs the training event rate. The structural model uses |m_t|, a five-point aligned slope, and state age. The enriched model adds aligned errors, winners, distance, rally count, current server, and elapsed points. All inputs are known after t only. A validation grid from 0.05 to 0.95 selects the F1 threshold.

We report AUC, average precision, log loss, precision, recall, F1, alarm fraction, and calibration. Since the event rate is high, an always-alarm rule can have a high F1. A real deployment would need event de-duplication, lead time, alert budgets, and intervention costs, none of which are observed here.''')
    pt=mdtable(['Model','Log loss ↓','Brier ↓','AUC ↑'],[[pnames[r.model],f'{r.log_loss:.4f}',f'{r.brier:.4f}',f'{r.auc:.4f}'] for r in point.itertuples()])
    add('Point test results: complexity did not pay',f'''{pt}

![Held-out point comparison](../results/figures/point_comparison.png)

The test set contains seven matches and 1,577 points. The fixed serve baseline is best. History versus score-context has paired loss difference **+0.002373**, with 95% match-cluster interval **[−0.000543, +0.004506]**. The interval contains zero.

The standardized coefficient of pre-point momentum is only about 0.0103 in the fitted history model; correlated lagged features make it inappropriate to interpret as a causal psychological effect. A visually plausible flow curve does not imply improved next-point prediction.''')
    add('Randomness results: insufficient evidence against the null',f'''![Permutation distribution](../results/figures/null_test.png)

The global mean lag statistic is **0.011878**, with two-sided permutation **p=0.405** and null central 95% interval approximately **[−0.03087, +0.01624]**. This is a reference distribution under the null, not a confidence interval for effect size.

Across 31 matches and two statistics, no test has q<0.05 after joint BH adjustment. The final's single-match lag statistic is −0.02535 (p=0.6575), and its cumulative statistic is 0.38230 (p=0.5375). The answer to the skeptical coach is therefore: **under this sample, these statistics, and this conditional null, we do not find enough evidence to reject random ordering.** This does not establish that all flow is random.''')
    add('Final case study: describe change without mythologizing',f'''![Final match flow](../results/figures/final_flow.png)

{mdtable(['Set','Games (1:2)','Points','Mean m (pp)','Reversals'],[[int(r.set_no),f'{int(r.p1_games_won)}:{int(r.p2_games_won)}',int(r.n),f'{r.mean_m_pp:+.2f}',int(r.flips)] for r in sets.itertuples()])}

Player 1 is Alcaraz and player 2 is Djokovic. Sets 1 and 4 have negative mean index; sets 2, 3, and 5 are positive. Set 3 reaches +13.66 percentage points. The fast index identifies **33 micro-state reversals** in the final, far more than the five macro set-level changes. Red points are retrospective confirmed reversals, not forecast hits; the lower panel shows pre-point probabilities.''')
    by=read('point_by_match.csv').pivot(index='match_id',columns='model',values='log_loss')
    add('Cross-match performance and a second case',f'''![Semifinal flow](../results/figures/semifinal_flow.png)

{mdtable(['Match suffix','Score loss','History loss','History − score'],[[i[-4:],f'{r.score_context:.4f}',f'{r.history:.4f}',f'{r.history-r.score_context:+.4f}'] for i,r in by.iterrows()])}

The history model lowers log loss in only two of seven test matches. In semifinal 1602, loss rises from 0.6329 to 0.6362; in the final it rises from 0.6765 to 0.6806. Improvements and deteriorations coexist, so average generalization gain is not established.

All tests come from one event, surface, and men's best-of-five format. Players can reappear across rounds; no name feature is used. This supports the stated cross-match scope, not transfer to new tournaments, women, surfaces, or sports.''')
    swt=mdtable(['Model','Log loss ↓','AUC ↑','AP ↑'],[[snames[r.model],f'{r.log_loss:.4f}',f'{r.auc:.4f}',f'{r.average_precision:.4f}'] for r in swing.itertuples()])
    add('Reversal prediction: the high-recall trap',f'''{swt}

![Swing calibration](../results/figures/swing_calibration.png)

There are **1,500 valid windows** with reversal rate **65.67%**. The structural model has AUC 0.6096 and AP 0.7305; the enriched model has AUC 0.5620 and log loss 0.6480. Its loss is 0.01941 worse than the structural model, with 95% cluster interval [0.01159, 0.02723]. The structural-versus-constant loss difference is −0.01589 with interval [−0.03510, +0.00028], still including zero.

The validation-selected structural threshold is 0.36: test precision is 65.97% and recall 99.80%. The enriched threshold falls to 0.05 and alarms on every test window, giving the same F1 as always alarming. Its 100% recall has no practical early-warning meaning. Calibration is window-level and overlapping.''')
    add('Sensitivity, ablation, and associative interpretation','''![Parameter sensitivity](../results/figures/sensitivity.png)

The nine candidate validation losses range from 0.61213 to 0.61443. The selected α=0.20, κ=30 is nearly tied with α=0.20, κ=60; these parameters are not precisely identified. Reversal event prevalence changes from 32.10% to 85.55% when H and δ vary, so F1 changes can be driven by label geometry.

Structural variables have signs consistent with the hysteresis definition: when the index is farther from the opposite threshold, an immediate reversal is less likely. Enriched coefficients are standardized training associations and do not justify fixed tactical prescriptions.

The ablation ladder compares fixed serve, online serve, score, and history models; the reversal task compares constant, structural, and enriched models. Together they show that extra variables and fit do not guarantee temporal generalization.''')
    add('Limits, transfer, and next steps','''**Statistical momentum is not psychological momentum.** EWMA is a chosen recent-deviation index; smoothing itself creates persistence. Its predictive behavior cannot establish a mental mechanism.

Ability changes are confounded. The conditional permutation null does not model fatigue, injury, court changes, or strategy shifts. Sample size is small: seven test matches and repeated players. More tournaments and player-grouped external validation are needed.

The dataset lacks injury, weather, rest, historical ratings, and intervention information. Missing ball-speed and depth fields were not imputed. For women's tennis, clay, hard courts, or table tennis, the same pipeline would require new serve priors, rules, time scales, and thresholds; no transfer accuracy is claimed.

Recommended next steps are full-season historical ability features, nested time validation, event-level reversal definitions, and explicit costs for alerts and interventions. These are future work, not completed experiments in this project.''')
    add('Coaching memo','''**Bottom line.** The curve is useful as an observation prompt. This dataset does not show that recent momentum reliably improves next-point prediction; serving remains the stable benchmark.

Before a match, estimate serving and returning ability for the new opponent. Do not transfer a previous opponent's momentum value directly. During a match, check whether a run coincides with the opponent's serve, first-serve quality, unforced errors, rally length, or physical state before changing tactics. Consecutive points alone do not prove a psychological collapse or a winning signal.

After a match, review the curve with video. The final produces 33 micro-reversals, so not every threshold crossing is a meaningful mental transition. The current alarm system should not be deployed: the enriched model effectively alarms everywhere. Any real deployment needs an alert budget, event-level lead time, false-alarm cost, and independent-match validation.

Keep the simple serve probability as the benchmark and use complex flow features for questions and review. Increase their decision weight only after they beat the benchmark on independent data.''')
    add('Reproduction and quality control','''The repository entry point is `README.md`. With Python 3.12, install `requirements.txt`, run `python scripts/download_data.py`, then `python -m src.analysis`. Results, tables, and figures are written to `results/`; no numbers are manually copied into the analysis output.

Run `python -m unittest discover -s tests -v` to check causality, player-swap symmetry, horizon censoring, the prior, BH correction, permutation repeatability, logistic intercept recovery, and official data counts. The GitHub workflow runs offline tests on pushes and pull requests; a manual workflow dispatch runs the full data download and experiment.

The report can be rebuilt with `python scripts/build_report.py --font PATH` after installing `requirements-report.txt`. Markdown, standalone HTML, and PDF are generated from the same narrative and result files. Floating-point tails, image bytes, and PDF metadata may vary by platform; fixed seeds and dependency pins make core values reproducible.

The release archive excludes raw CSVs, caches, virtual environments, and temporary files. The official downloader and SHA-256 check recover the data locally.''')
    add('References and evidence index','''**[1] COMAP.** 2024 MCM Problem C: Momentum in Tennis. Official statement, 2024. https://www.contest.comap.com/undergraduate/contests/mcm/contests/2024/problems/2024_MCM_Problem_C.pdf

**[2] COMAP.** Momentum in Tennis, official problem and data resource page. https://www.comap.org/membership/member-resources/item/momentum-in-tennis (accessed 2026-10-19).

**[3] NIST/SEMATECH.** e-Handbook of Statistical Methods, 6.3.2.4: EWMA Control Charts. https://www.itl.nist.gov/div898/handbook/pmc/section3/pmc324.htm

**[4] scikit-learn developers.** `log_loss` API documentation. https://scikit-learn.org/stable/modules/generated/sklearn.metrics.log_loss.html

**[5] scikit-learn developers.** Metrics API reference. https://scikit-learn.org/stable/api/sklearn.metrics.html

| Claim | File under `results/` |
| --- | --- |
| Data scale, settings, intervals | `summary.json` |
| Point model performance | `tables/point_metrics.csv`, `point_by_match.csv` |
| Conditional randomness | `tables/permutation_tests.csv` |
| Reversal performance | `tables/swing_metrics.csv`, `swing_by_match.csv` |
| Sensitivity | `tables/sensitivity.csv`, `swing_sensitivity_validation.csv` |
| Final summaries | `tables/final_sets.csv`, `final_reversals.csv` |
| Every prediction and label | `tables/point_predictions.csv`, `swing_predictions.csv` |

The formulas are this project's model definitions and derivations. The original statement and data remain third-party materials and are not relicensed by the repository MIT license.''')
    add('Appendix: AI use and research integrity','''**Tool.** OpenAI Codex assisted this project; the base model is in the GPT-6 family, but no independently verifiable build identifier is available, so no version number is invented. Date: 2026-10-19.

**User request.** “Choose a recent American college mathematical modeling contest problem, solve it in detail, and organize the result in a GitHub-ready format.”

**Scope of assistance.** AI assisted topic selection, official-source retrieval, model definition, Python implementation, experiment execution, plots, English and Chinese report writing, and repository structure. Empirical numbers come from official point data; synthetic data are used only as test fixtures.

**Verification.** The project performs SHA-256 validation, schema and order checks, temporal holdout, explicit pre/post-point separation, future-perturbation and player-swap tests, reproducible permutation tests, and PDF visual review. There was no independent sports-expert review, cross-event validation, coaching intervention trial, or cloud CI run claimed in this report.

This appendix documents the assistance method; it is not a substitute for a contest's required full interaction log. Future formal use should follow the applicable contest rules and add the user's independent verification and contributions.''')
    return pages
