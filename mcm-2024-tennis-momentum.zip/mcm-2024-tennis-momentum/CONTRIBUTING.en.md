# Contributing

Contributions are welcome for data audits, reproducible model comparisons, external validation, and report corrections.

For model changes, document when each feature becomes available and preserve time- or match-separated validation. Do not use the test set for tuning. Keep baselines, failed results, random seeds, and data sources. Update the report narrative when default results change.

Run `python -m unittest discover -s tests -v`. Do not commit raw third-party data or reproduce the full official problem statement without permission.
