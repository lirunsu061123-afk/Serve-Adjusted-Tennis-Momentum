# Raw Data

Run `python scripts/download_data.py` from the repository root to download the official COMAP archive.

- Official page: https://www.comap.org/membership/member-resources/item/momentum-in-tennis
- Files: `2024_Wimbledon_featured_matches.csv` and `2024_data_dictionary.csv`
- Local names: `Wimbledon_featured_matches.csv` and `data_dictionary.csv`
- Match-data SHA-256: `b1788d0ea169b65629b0e9fb0f91d007507b306e404507bbf90bd5f700a3c229`
- Retrieval date: 2026-10-19

The downloader stops if the checksum changes. Raw data remain third-party materials and are excluded from the MIT license and publication archive.
