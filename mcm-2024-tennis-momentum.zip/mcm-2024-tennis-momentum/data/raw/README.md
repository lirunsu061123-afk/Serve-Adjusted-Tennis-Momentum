# 原始数据

运行 `python scripts/download_data.py` 从 COMAP 官方资源页面下载数据。

- 官方入口：https://www.comap.org/membership/member-resources/item/momentum-in-tennis
- 下载文件：`2024_Wimbledon_featured_matches.csv`、`2024_data_dictionary.csv`
- 本地标准文件名：`Wimbledon_featured_matches.csv`、`data_dictionary.csv`
- 比赛数据 SHA-256：`b1788d0ea169b65629b0e9fb0f91d007507b306e404507bbf90bd5f700a3c229`
- 获取日期：2026-10-19。

下载脚本在哈希不一致时停止。若官方链接改变，应到官方入口重新获取，核对文件后再修改脚本。
原始数据归原权利人所有，不包含在发布 ZIP 中，也不受仓库 MIT 许可覆盖。
本地工作副本可含已下载的数据；`.gitignore` 排除它们，推送前使用 `git status` 核对。
