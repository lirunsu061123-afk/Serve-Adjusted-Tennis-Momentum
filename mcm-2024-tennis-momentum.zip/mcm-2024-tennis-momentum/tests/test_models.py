"""Meaningful invariants: causality, player symmetry, and valid diagnostics."""
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from src.model import features, POINT_BASE, POINT_EXTRA, SWING_BASE, SWING_EXTRA, OffsetLogit
from src.analysis import bh, permutation_tests


def fixture(n=80):
    rng=np.random.default_rng(78)
    return pd.DataFrame({
        'match_id':['synthetic']*n,'point_no':np.arange(1,n+1),'set_no':1,
        'split':'test','server':np.where((np.arange(n)//4)%2==0,1,2),
        'point_victor':rng.integers(1,3,n),'y':rng.integers(0,2,n),
        'p1_score':'0','p2_score':'0','p1_sets':0,'p2_sets':0,
        'p1_games':0,'p2_games':0,'p1_break_pt':0,'p2_break_pt':0,
        'p1_unf_err':rng.integers(0,2,n),'p2_unf_err':rng.integers(0,2,n),
        'p1_winner':rng.integers(0,2,n),'p2_winner':rng.integers(0,2,n),
        'p1_distance_run':rng.random(n)*20,'p2_distance_run':rng.random(n)*20,
        'rally_count':rng.integers(1,12,n)}) .assign(y=lambda d:(d.point_victor==1).astype(int))


class ModelTests(unittest.TestCase):
    def test_future_cannot_change_past_features(self):
        d=fixture(); e=d.copy(); e.loc[40:,'y']=1-e.loc[40:,'y']; e.loc[40:,'point_victor']=3-e.loc[40:,'point_victor']
        e.loc[40:,'p1_unf_err']=1-e.loc[40:,'p1_unf_err']
        a=features(d,.66); b=features(e,.66)
        np.testing.assert_allclose(a.loc[:40,POINT_BASE+POINT_EXTRA+['p_online']],b.loc[:40,POINT_BASE+POINT_EXTRA+['p_online']])
        np.testing.assert_allclose(a.loc[:39,SWING_BASE+SWING_EXTRA],b.loc[:39,SWING_BASE+SWING_EXTRA])

    def test_player_swap_symmetry(self):
        d=fixture(); e=d.copy()
        for col in d:
            if col.startswith('p1_'):
                e[col]=d[col.replace('p1_','p2_')];e[col.replace('p1_','p2_')]=d[col]
        e['server']=3-d.server;e['point_victor']=3-d.point_victor;e['y']=1-d.y
        a=features(d,.66);b=features(e,.66)
        np.testing.assert_allclose(a.m,-b.m,atol=1e-12)
        np.testing.assert_allclose(a.p_online,1-b.p_online,atol=1e-12)
        np.testing.assert_allclose(a.swing_y,b.swing_y,equal_nan=True)

    def test_horizon_excludes_current_point_and_censors_tail(self):
        f=features(fixture(),.66,horizon=10)
        self.assertTrue(f.swing_y.tail(10).isna().all())
        for i,r in f.iloc[:-10].iterrows():
            if r.state:
                self.assertEqual(r.swing_y,int(f.flip.iloc[i+1:i+11].any()))

    def test_beta_prior_at_first_point(self):
        d=fixture();f=features(d,.66)
        self.assertAlmostEqual(f.p_online.iloc[0],.66)
        self.assertEqual(f.m_before.iloc[0],0)

    def test_bh_known_values(self):
        np.testing.assert_allclose(bh([.01,.04,.03,.2]),[.04,.05333333333,.05333333333,.2])

    def test_permutation_repeatability_and_valid_p(self):
        a,g,_=permutation_tests(fixture(),99,5);b,h,_=permutation_tests(fixture(),99,5)
        pd.testing.assert_frame_equal(a,b);self.assertEqual(g,h)
        self.assertTrue(a[['p_rho','p_cusum']].ge(.01).all().all())

    def test_offset_model_recovers_intercept(self):
        d=pd.DataFrame({'x':np.zeros(100),'y':[1]*70+[0]*30,'p':.5})
        model=OffsetLogit(['x']).fit(d,offset='p')
        np.testing.assert_allclose(model.predict(d),.7,atol=1e-4)

    def test_actual_data_counts_when_available(self):
        from src.model import load_data
        path=Path(__file__).resolve().parents[1]/'data/raw/Wimbledon_featured_matches.csv'
        if not path.exists():self.skipTest('Official data not downloaded')
        d=load_data(path)
        self.assertEqual(len(d),7284);self.assertEqual(d.match_id.nunique(),31)


if __name__=='__main__':unittest.main()
