"""Causal feature construction and small regularized statistical models.

Point predictions use information strictly before the point. Swing predictions
are made after a point has finished. No point-end fields enter that point's model.
"""
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit, logit

POINT_BASE = ['server_sign', 'set_diff', 'game_diff', 'score_diff', 'break_diff']
POINT_EXTRA = ['m_before', 'errors_before', 'winners_before', 'distance_before']
SWING_BASE = ['abs_m', 'aligned_slope', 'state_age']
SWING_EXTRA = ['aligned_errors', 'aligned_winners', 'aligned_distance',
               'rally_recent', 'aligned_server', 'elapsed_points']


def load_data(path):
    d = pd.read_csv(path).sort_values(['match_id', 'point_no']).reset_index(drop=True)
    required = ['match_id', 'point_no', 'server', 'point_victor']
    if d[required].isna().any().any():
        raise ValueError('Missing key fields')
    if d.duplicated(['match_id', 'point_no']).any():
        raise ValueError('Duplicate point identity')
    for col in ['server', 'point_victor']:
        if not d[col].isin([1, 2]).all():
            raise ValueError(f'Invalid {col}')
    for _, g in d.groupby('match_id'):
        if not np.array_equal(g.point_no, np.arange(1, len(g)+1)):
            raise ValueError('Nonconsecutive points')
    d['round'] = d.match_id.str[-3].astype(int)
    d['split'] = np.where(d['round'] == 3, 'train',
                          np.where(d['round'] == 4, 'validation', 'test'))
    d['y'] = (d.point_victor == 1).astype(int)
    return d


def serve_rate(d):
    return float((d.server == d.point_victor).mean())


def score_value(v):
    # A score in a tie-break is a literal integer; ordinary scores are ordinal.
    return {'0': 0, '15': 1, '30': 2, '40': 3, 'AD': 4}.get(str(v), float(v) if str(v).isdigit() else 0)


def features(d, q, alpha=.1, kappa=30, threshold=.08, horizon=10, crossfit=False):
    """At point t, baseline Beta updates use only points <t.

    When crossfit=True, the global serve rate for each training match excludes
    that match. Validation and test always use the original training-only q.
    """
    output = []
    train = d[d.split == 'train']
    for mid, g in d.groupby('match_id', sort=True):
        qg = serve_rate(train[train.match_id != mid]) if crossfit and g.iloc[0].split == 'train' else q
        won = np.zeros(2); count = np.zeros(2)
        m = err = winner = dist = rally = 0.
        state = age = 0; hist = []; records = []
        for t, row in enumerate(g.itertuples()):
            s = row.server - 1; sign = 1 if s == 0 else -1
            ps = (kappa*qg + won[s]) / (kappa + count[s])
            p = ps if s == 0 else 1-ps
            a, b = str(row.p1_score), str(row.p2_score)
            is_tb = row.p1_games == 6 and row.p2_games == 6
            sd = float(a)-float(b) if is_tb else score_value(a)-score_value(b)
            rec = {'match_id': mid, 'point_no': row.point_no, 'set_no': row.set_no,
                   'split': row.split, 'y': row.y, 'p_online': p,
                   'p_global': qg if s == 0 else 1-qg,
                   'server_sign': sign, 'set_diff': row.p1_sets-row.p2_sets,
                   'game_diff': row.p1_games-row.p2_games, 'score_diff': np.clip(sd,-4,4),
                   'break_diff': row.p1_break_pt-row.p2_break_pt,
                   'm_before': m, 'errors_before': err, 'winners_before': winner,
                   'distance_before': dist}
            residual = row.y-p
            m = (1-alpha)*m + alpha*residual
            err = .9*err + .1*(row.p2_unf_err-row.p1_unf_err)
            winner = .9*winner + .1*(row.p1_winner-row.p2_winner)
            dist = .9*dist + .1*(row.p2_distance_run-row.p1_distance_run)
            rally = .9*rally + .1*row.rally_count
            previous = state
            if m > threshold: state = 1
            elif m < -threshold: state = -1
            age = age+1 if state == previous else 1
            flip = int(previous != 0 and state != previous)
            slope = m-(hist[-5] if len(hist) >= 5 else 0.)
            hist.append(m)
            rec.update(m=m, residual=residual, state=state, flip=flip,
                       abs_m=abs(m), aligned_slope=state*slope, state_age=min(age,100)/100,
                       aligned_errors=state*err, aligned_winners=state*winner,
                       aligned_distance=state*dist, rally_recent=rally,
                       aligned_server=state*sign, elapsed_points=(t+1)/300)
            records.append(rec)
            won[s] += int(row.server == row.point_victor); count[s] += 1
        flips = np.array([r['flip'] for r in records])
        for t, rec in enumerate(records):
            rec['swing_y'] = int(flips[t+1:t+horizon+1].any()) if t+horizon < len(records) and rec['state'] else np.nan
        output.extend(records)
    return pd.DataFrame(output)


class OffsetLogit:
    """L2 logistic regression, optional fixed baseline log odds.

    Objective: mean binary cross entropy + 0.5*penalty*||beta||^2.
    Features are standardized using training data only. Intercept unpenalized.
    """
    def __init__(self, columns, penalty=.01):
        self.columns = columns; self.penalty = penalty

    def fit(self, d, target='y', offset=None):
        x = d[self.columns].to_numpy(float)
        self.mean = x.mean(0); self.scale = x.std(0)
        self.scale[self.scale < 1e-10] = 1
        x = np.c_[np.ones(len(x)), (x-self.mean)/self.scale]
        y = d[target].to_numpy(float)
        off = np.zeros(len(d)) if offset is None else logit(np.clip(d[offset],1e-6,1-1e-6))
        def objective(beta):
            z = x@beta+off
            loss = np.mean(np.logaddexp(0,z)-y*z)+.5*self.penalty*np.sum(beta[1:]**2)
            grad = x.T@(expit(z)-y)/len(y)
            grad[1:] += self.penalty*beta[1:]
            return loss, grad
        fit = minimize(objective,np.zeros(x.shape[1]),jac=True,method='L-BFGS-B',options={'maxiter':1000,'ftol':1e-12})
        if not fit.success: raise RuntimeError(fit.message)
        self.beta = fit.x; self.offset = offset
        return self

    def predict(self,d):
        x = (d[self.columns].to_numpy(float)-self.mean)/self.scale
        off = 0 if self.offset is None else logit(np.clip(d[self.offset],1e-6,1-1e-6))
        return expit(self.beta[0]+x@self.beta[1:]+off)

    def coefficients(self):
        return pd.DataFrame({'feature':['intercept']+self.columns,'standardized_coefficient':self.beta})
