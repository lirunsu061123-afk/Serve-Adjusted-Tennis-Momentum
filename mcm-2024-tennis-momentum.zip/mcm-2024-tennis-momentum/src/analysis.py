"""Run actual experiments; all reported numerical results originate here."""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import importlib.metadata
import numpy as np
import pandas as pd
from sklearn.metrics import (log_loss, roc_auc_score, average_precision_score,
                             precision_score, recall_score, f1_score)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .model import (load_data, serve_rate, features, OffsetLogit, POINT_BASE,
                    POINT_EXTRA, SWING_BASE, SWING_EXTRA)

ROOT = Path(__file__).resolve().parents[1]
SEED = 20241019


def metrics(y,p,threshold=.5):
    y=np.asarray(y); p=np.asarray(p)
    return {'n':len(y),'prevalence':float(y.mean()),'log_loss':float(log_loss(y,p,labels=[0,1])),
            'brier':float(np.mean((y-p)**2)),
            'auc':float(roc_auc_score(y,p)) if len(np.unique(y))>1 else None,
            'average_precision':float(average_precision_score(y,p)),
            'precision':float(precision_score(y,p>=threshold,zero_division=0)),
            'recall':float(recall_score(y,p>=threshold,zero_division=0)),
            'f1':float(f1_score(y,p>=threshold,zero_division=0)),
            'alarm_fraction':float(np.mean(p>=threshold)),
            'threshold':float(threshold)}


def bh(p):
    p=np.asarray(p); order=np.argsort(p)
    out=np.empty(len(p)); out[order]=np.minimum(1,np.minimum.accumulate((p[order]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1])
    return out


def permutation_tests(d, B, seed):
    rng=np.random.default_rng(seed); records=[]; null_rhos=[]; observed=[]
    for mid,g in d.groupby('match_id'):
        y=g.y.to_numpy(float); s=g.server.to_numpy(); n=len(y)
        p=np.array([y[s==v].mean() for v in s]); r=y-p
        denom=np.sum(r*r)
        rho=float(np.sum(r[1:]*r[:-1])/denom)
        cusum=float(np.max(np.abs(np.cumsum(r)))/np.sqrt(n))
        sims=np.empty((B,n))
        for v in [1,2]:
            ix=np.flatnonzero(s==v)
            # Separate random permutations in each row, holding serve positions fixed.
            order=np.argsort(rng.random((B,len(ix))),axis=1)
            sims[:,ix]=y[ix][order]
        rr=sims-p
        nr=np.sum(rr[:,1:]*rr[:,:-1],axis=1)/denom
        nc=np.max(np.abs(np.cumsum(rr,axis=1)),axis=1)/np.sqrt(n)
        records.append({'match_id':mid,'n':n,'rho':rho,'cusum':cusum,
                        'p_rho':(1+np.sum(np.abs(nr)>=abs(rho)))/(B+1),
                        'p_cusum':(1+np.sum(nc>=cusum))/(B+1)})
        null_rhos.append(nr); observed.append(rho)
    out=pd.DataFrame(records)
    # Correct all 62 tests together, rather than selecting a favorable statistic.
    corrected=bh(np.r_[out.p_rho,out.p_cusum])
    out['q_rho']=corrected[:len(out)]; out['q_cusum']=corrected[len(out):]
    obs=float(np.mean(observed)); null=np.mean(null_rhos,axis=0)
    global_result={'mean_rho':obs,'p_two_sided':float((1+np.sum(abs(null)>=abs(obs)))/(B+1)),
                   'null_interval_95':np.quantile(null,[.025,.975]).tolist(), 'B':B,
                   'fdr_significant_tests':int((corrected<.05).sum())}
    return out,global_result,null


def bootstrap_difference(d, a, b, target='y', B=3000):
    """Match-cluster bootstrap of point-weighted paired log-loss difference a-b."""
    parts=[]
    for _,g in d.groupby('match_id'):
        y=g[target].to_numpy()
        def losses(col):
            p=np.clip(g[col].to_numpy(),1e-9,1-1e-9)
            return -(y*np.log(p)+(1-y)*np.log(1-p))
        parts.append([np.sum(losses(a)-losses(b)),len(g)])
    parts=np.array(parts); rng=np.random.default_rng(SEED+1)
    ix=rng.integers(len(parts),size=(B,len(parts)))
    vals=parts[ix,0].sum(1)/parts[ix,1].sum(1)
    return {'difference_a_minus_b':float(parts[:,0].sum()/parts[:,1].sum()),
            'ci95':np.quantile(vals,[.025,.975]).tolist(),'clusters':len(parts),'B':B}


def save_plot(path):
    plt.savefig(path,dpi=180,bbox_inches='tight',facecolor='white'); plt.close()


def plot_flow(f, raw, mid, dest):
    g=f[f.match_id==mid]; r=raw[raw.match_id==mid]; x=g.point_no.to_numpy(); m=g.m.to_numpy()*100
    fig,axes=plt.subplots(2,1,figsize=(11.5,6.8),sharex=True,gridspec_kw={'height_ratios':[2,1]})
    ax=axes[0]; ax.plot(x,m,color='#183f57',lw=1.6)
    ax.fill_between(x,0,m,where=m>=0,color='#148f88',alpha=.25)
    ax.fill_between(x,0,m,where=m<0,color='#d77e35',alpha=.25)
    ax.axhline(8,color='#148f88',ls='--',alpha=.6); ax.axhline(-8,color='#d77e35',ls='--',alpha=.6)
    ax.axhline(0,color='#83929c',lw=.7); ax.set_ylabel('Serve-adjusted momentum\n(percentage points)')
    ax.set_title(f'{r.iloc[0].player1} vs {r.iloc[0].player2} | {mid}',loc='left',weight='bold')
    for sn,sg in g.groupby('set_no'):
        start=sg.point_no.min(); end=sg.point_no.max()
        ax.axvline(start,color='#a8b5be',alpha=.5,lw=.7)
        ax.text((start+end)/2,ax.get_ylim()[1]*.85,f'Set {sn}',ha='center',fontsize=9)
    flip=g[g.flip==1]; ax.scatter(flip.point_no,flip.m*100,s=28,color='#962f46',zorder=5,label='Confirmed state reversal')
    ax.legend(loc='lower left',fontsize=8)
    axes[1].plot(x,g.p_online,color='#83929c',alpha=.8,lw=.8,label='Online serve baseline')
    axes[1].plot(x,g.pred_momentum,color='#166f7b',alpha=.8,lw=.9,label='History model')
    axes[1].set_ylabel('P(player 1 wins point)'); axes[1].set_ylim(0,1)
    axes[1].set_xlabel('Point number (entire match)'); axes[1].legend(fontsize=8,ncol=2)
    for a in axes: a.spines[['top','right']].set_visible(False); a.grid(axis='y',alpha=.15)
    fig.tight_layout(); save_plot(dest)


def run(B=1999):
    tables=ROOT/'results/tables'; figs=ROOT/'results/figures'
    tables.mkdir(parents=True,exist_ok=True); figs.mkdir(parents=True,exist_ok=True)
    path=ROOT/'data/raw/Wimbledon_featured_matches.csv'; raw=load_data(path)
    q=serve_rate(raw[raw.split=='train'])
    audit={'rows':len(raw),'matches':int(raw.match_id.nunique()),'columns_original':46,
           'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'serve_rate_train':q,
           'serve_rate_all_descriptive':serve_rate(raw),
           'missing':raw.isna().sum()[lambda v:v>0].to_dict(),
           'splits':{s:{'matches':int(g.match_id.nunique()),'points':len(g)} for s,g in raw.groupby('split')}}
    sensitivity=[]; candidates={}
    for alpha in [.05,.1,.2]:
        for kappa in [10,30,60]:
            f=features(raw,q,alpha,kappa,crossfit=True)
            tr=f[f.split=='train']; va=f[f.split=='validation']
            model=OffsetLogit(POINT_BASE+POINT_EXTRA).fit(tr,offset='p_online')
            loss=log_loss(va.y,model.predict(va))
            sensitivity.append({'alpha':alpha,'kappa':kappa,'validation_log_loss':loss})
            candidates[(alpha,kappa)]=(f,model)
    sens=pd.DataFrame(sensitivity).sort_values('validation_log_loss'); sens.to_csv(tables/'sensitivity.csv',index=False)
    chosen=sens.iloc[0]; alpha=float(chosen.alpha); kappa=int(chosen.kappa)
    f,model=candidates[(alpha,kappa)]; tr=f[f.split=='train']
    context=OffsetLogit(POINT_BASE).fit(tr,offset='p_online')
    f['pred_context']=context.predict(f); f['pred_momentum']=model.predict(f)
    point_rows=[]
    for split,g in f.groupby('split'):
        for label,col in [('global_serve','p_global'),('online_serve','p_online'),('score_context','pred_context'),('history','pred_momentum')]:
            point_rows.append({'split':split,'model':label,**metrics(g.y,g[col])})
    pd.DataFrame(point_rows).to_csv(tables/'point_metrics.csv',index=False)
    test=f[f.split=='test']; ci=bootstrap_difference(test,'pred_momentum','pred_context')
    per_match=[]
    for mid,g in test.groupby('match_id'):
        for label,col in [('online_serve','p_online'),('score_context','pred_context'),('history','pred_momentum')]:
            per_match.append({'match_id':mid,'model':label,**metrics(g.y,g[col])})
    pd.DataFrame(per_match).to_csv(tables/'point_by_match.csv',index=False)
    model.coefficients().to_csv(tables/'point_coefficients.csv',index=False)
    # Swing classification is deliberately a separate after-point prediction task.
    sw=f.dropna(subset=['swing_y']).copy(); st=sw[sw.split=='train']; sv=sw[sw.split=='validation']
    sw['constant']=st.swing_y.mean()
    swing_rows=[]; thresholds={}
    for label,cols in [('structural',SWING_BASE),('enriched',SWING_BASE+SWING_EXTRA)]:
        sm=OffsetLogit(cols).fit(st,target='swing_y'); sw[label]=sm.predict(sw)
        vp=sm.predict(sv)
        grid=np.linspace(.05,.95,91)
        threshold=float(grid[np.argmax([f1_score(sv.swing_y,vp>=v,zero_division=0) for v in grid])])
        thresholds[label]=threshold
        sm.coefficients().to_csv(tables/f'swing_{label}_coefficients.csv',index=False)
    thresholds['constant']=.5
    for split,g in sw.groupby('split'):
        for label in ['constant','structural','enriched']:
            swing_rows.append({'split':split,'model':label,**metrics(g.swing_y,g[label],thresholds[label])})
    pd.DataFrame(swing_rows).to_csv(tables/'swing_metrics.csv',index=False)
    swing_match=[]
    for mid,g in sw[sw.split=='test'].groupby('match_id'):
        for label in ['constant','structural','enriched']:
            swing_match.append({'match_id':mid,'model':label,**metrics(g.swing_y,g[label],thresholds[label])})
    pd.DataFrame(swing_match).to_csv(tables/'swing_by_match.csv',index=False)
    sci=bootstrap_difference(sw[sw.split=='test'],'enriched','structural','swing_y')
    sw.to_csv(tables/'swing_predictions.csv',index=False)
    f.to_csv(tables/'point_predictions.csv',index=False)
    # Temporal clustering diagnostic is retrospective and independent of EWMA choices.
    perm,global_test,null=permutation_tests(raw,B,SEED)
    perm.to_csv(tables/'permutation_tests.csv',index=False)
    # Label robustness: fixed model parameters; retrain classifier, no extra model choice.
    robustness=[]
    for h in [5,10,15]:
        for threshold in [.05,.08,.12]:
            ss=features(raw,q,alpha,kappa,threshold,h,crossfit=True).dropna(subset=['swing_y'])
            mm=OffsetLogit(SWING_BASE+SWING_EXTRA).fit(ss[ss.split=='train'],target='swing_y')
            vv=ss[ss.split=='validation']
            robustness.append({'horizon':h,'state_threshold':threshold,**metrics(vv.swing_y,mm.predict(vv))})
    pd.DataFrame(robustness).to_csv(tables/'swing_sensitivity_validation.csv',index=False)
    final=f[f.match_id=='2023-wimbledon-1701']; rf=raw[raw.match_id=='2023-wimbledon-1701']
    sets=[]
    for sn,g in final.groupby('set_no'):
        r=rf[rf.set_no==sn]
        sets.append({'set_no':int(sn),'n':len(g),'p1_points':int(g.y.sum()),
                     'p1_games_won':int((r.game_victor==1).sum()),'p2_games_won':int((r.game_victor==2).sum()),
                     'mean_m_pp':float(100*g.m.mean()),'end_m_pp':float(100*g.m.iloc[-1]),'flips':int(g.flip.sum())})
    pd.DataFrame(sets).to_csv(tables/'final_sets.csv',index=False)
    final[final.flip==1][['point_no','set_no','m','state']].to_csv(tables/'final_reversals.csv',index=False)
    plot_flow(f,raw,'2023-wimbledon-1701',figs/'final_flow.png')
    plot_flow(f,raw,'2023-wimbledon-1602',figs/'semifinal_flow.png')
    plt.figure(figsize=(8,4.5));plt.hist(null,bins=40,color='#9cc8cf',edgecolor='white')
    plt.axvline(global_test['mean_rho'],color='#a83b45',lw=2,label=f"Observed mean = {global_test['mean_rho']:.4f}")
    plt.xlabel('Mean within-match lag-1 residual statistic');plt.ylabel('Permutation frequency')
    plt.title(f'Conditional random-order null | {B:,} permutations');plt.legend();save_plot(figs/'null_test.png')
    pm=pd.DataFrame(point_rows); pmt=pm[pm.split=='test']
    fig,ax=plt.subplots(figsize=(8,4.5));ax.bar(pmt.model,pmt.log_loss,color=['#b8c4cc','#7babb4','#3d899b','#183f57'])
    ax.set_ylim(.55,max(.70,pmt.log_loss.max()+.02));ax.set_ylabel('Held-out point log loss (lower is better)')
    for i,v in enumerate(pmt.log_loss):ax.text(i,v+.002,f'{v:.4f}',ha='center')
    ax.set_title('Rounds 5-7 held out | 7 matches');save_plot(figs/'point_comparison.png')
    fig,ax=plt.subplots(figsize=(7,4.5));ax.plot([0,1],[0,1],'--',color='#9ca7ac')
    for col in ['structural','enriched']:
        g=sw[sw.split=='test'].copy(); g['bin']=pd.cut(g[col],bins=np.linspace(0,1,6),include_lowest=True)
        cal=g.groupby('bin',observed=True).agg(pred=(col,'mean'),observed=('swing_y','mean'),n=('swing_y','size'))
        cal.to_csv(tables/f'calibration_{col}.csv')
        ax.plot(cal.pred,cal.observed,'o-',label=col)
    ax.set(xlabel='Predicted reversal probability',ylabel='Observed reversal fraction',xlim=(0,1),ylim=(0,1),title='Reversal calibration | test matches')
    ax.legend();save_plot(figs/'swing_calibration.png')
    fig,ax=plt.subplots(figsize=(7,4.5)); pivot=sens.pivot(index='alpha',columns='kappa',values='validation_log_loss')
    im=ax.imshow(pivot.values,cmap='YlGnBu');ax.set_xticks(range(3),pivot.columns);ax.set_yticks(range(3),pivot.index)
    ax.set(xlabel='Prior effective sample size kappa',ylabel='EWMA alpha',title='Validation log loss | history model')
    for i in range(3):
        for j in range(3):ax.text(j,i,f'{pivot.iloc[i,j]:.4f}',ha='center',va='center',color='black',bbox={'facecolor':'white','alpha':.75,'edgecolor':'none'})
    fig.colorbar(im,ax=ax);save_plot(figs/'sensitivity.png')
    summary={'seed':SEED,'data':audit,'selected':{'alpha':alpha,'kappa':kappa,'threshold':.08,'horizon':10},
             'point_test_ci':ci,'swing_test_ci':sci,'global_permutation':global_test,
             'history_vs_global_ci':bootstrap_difference(test,'pred_momentum','p_global'),
             'structural_vs_constant_ci':bootstrap_difference(sw[sw.split=='test'],'structural','constant','swing_y'),
             'final_flips':int(final.flip.sum()),'swing_thresholds':thresholds,
             'environment':{'python':platform.python_version(),**{v:importlib.metadata.version(v) for v in ['numpy','pandas','scipy','scikit-learn','matplotlib']}}}
    (ROOT/'results/summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(summary,indent=2,ensure_ascii=False))
    print(pm[pm.split=='test'].to_string(index=False))
    print(pd.DataFrame(swing_rows).query("split == 'test'").to_string(index=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--permutations',type=int,default=1999)
    run(parser.parse_args().permutations)
