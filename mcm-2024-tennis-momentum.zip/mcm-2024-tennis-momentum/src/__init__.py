"""Reproducible, serve-adjusted tennis momentum analysis."""
