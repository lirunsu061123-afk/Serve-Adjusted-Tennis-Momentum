# Tennis Momentum · 2024 MCM Problem C

This repository contains a reproducible study of “momentum” in tennis using COMAP’s official 2023 Wimbledon men’s data: 7,284 points from 31 matches.

The project implements an online Beta-Bernoulli serve baseline, an EWMA residual momentum index, conditional permutation tests, point-level prediction, reversal prediction, sensitivity analysis, figures, tests, and a full English report.

## Main findings

- The serve-adjusted index describes match flow, but it is retrospective and is not evidence of a psychological mechanism.
- The global conditional permutation test gives **p = 0.405**; none of 62 match-level tests remains significant after multiplicity adjustment.
- On 1,577 held-out points, the fixed serve baseline has log loss **0.6428**. Adding score and history gives **0.6458**, with no stable improvement.
- The structural reversal model reaches AUC **0.6096**. Adding technical variables lowers AUC to **0.5620**.

The project is an independent post-hoc research demonstration, not an award paper or official contest submission.

## Quick start

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python scripts/download_data.py
python -m src.analysis
python -m unittest discover -s tests -v
```

Build the English report with `python scripts/build_report.py --english` after installing `requirements-report.txt`. The report builder also accepts `--font PATH` when a CJK font is needed for the Chinese edition.

## Repository guide

- [English report](docs/report.en.md), [PDF](docs/report.en.pdf), and [offline HTML](docs/report.en.html)
- [English data card](docs/DATA_CARD.en.md)
- [English model card](docs/MODEL_CARD.en.md)
- [English coaching memo](docs/COACH_MEMO.en.md)
- [English AI-use disclosure](docs/AI_USAGE.en.md)
- [English release checks](docs/RELEASE_CHECKS.en.md)
- `src/`: feature construction, online baseline, and models
- `scripts/`: official-data downloader, analysis runner, and report builder
- `results/`: machine-readable tables, summary JSON, and figures
- `tests/`: causality, symmetry, censoring, reproducibility, and model invariants

Raw COMAP data are third-party materials. They are excluded from the publication archive; `scripts/download_data.py` downloads and verifies them with SHA-256. Original code and documentation are released under MIT; see `LICENSE`.
