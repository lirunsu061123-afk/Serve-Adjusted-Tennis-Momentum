# Model Card

## Purpose

The project studies whether a serve-adjusted momentum index can describe tennis match flow, test a random-order explanation, and improve out-of-sample point or reversal prediction. It is intended for education, reproducible research, and post-match review. It is not validated for live tactical automation.

## Models

1. A Beta-Bernoulli online serve baseline updates separately for each player within each match.
2. Momentum is the EWMA of the residual `y_t - p_t`, with selected `alpha = 0.20`, prior effective sample size `kappa = 30`, and state threshold `delta = 0.08`.
3. Offset logistic models compare serve-only, score-context, and history-enriched point probabilities.
4. Constant, structural, and enriched logistic models predict whether the state reverses within the next ten points.
5. Conditional permutation tests preserve serve positions and within-serve-stratum totals. The main experiment uses 1,999 permutations.

## Validation

Models are split by tournament round: 16 training matches, eight validation matches, and seven held-out test matches. Hyperparameters are selected on validation data only. The same player can appear in different rounds, so this is not a new-player validation design.

The history-enriched point model does not beat the simple serve baseline. The structural reversal model has limited ranking ability; the technical-variable extension performs worse. High reversal prevalence makes recall and F1 easy to inflate.

## Limitations

The EWMA is an operational statistic, not a measured psychological state. Conditional permutation does not model fatigue, injury, tactics, weather, or the full tennis scoring process. The dataset covers one tournament, one surface, and men’s matches only. Reversal windows overlap, and the test set contains only seven matches. Missing environmental and medical variables are unavailable.

Use the simple serve baseline as the default benchmark. Treat added features as hypotheses requiring external validation, event-level cost evaluation, and prospective testing.
