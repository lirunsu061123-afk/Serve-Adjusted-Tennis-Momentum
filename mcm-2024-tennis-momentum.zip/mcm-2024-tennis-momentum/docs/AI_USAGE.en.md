# AI Use Disclosure

OpenAI Codex assisted with topic selection, official-source retrieval, model formulation, Python implementation, experiments, figures, English and Chinese writing, and repository organization. The exact model build was not independently verifiable, so no fabricated version number is given. Date: 2026-10-19.

All empirical numbers come from the official point-level dataset. Synthetic data are used only in unit-test fixtures. The project performed SHA-256 verification, field audits, round-based holdout evaluation, causal-timing checks, player-swap checks, permutation reproducibility checks, and visual PDF review.

There has been no independent sports-expert review, cross-tournament validation, prospective coaching trial, or cloud CI run claimed as evidence. This is not an official contest submission and does not claim an award.

This disclosure describes the assistance and verification process; it is not a substitute for any contest’s required verbatim interaction log. A future formal submission should follow the rules in force for that contest and independently verify every citation and conclusion.
