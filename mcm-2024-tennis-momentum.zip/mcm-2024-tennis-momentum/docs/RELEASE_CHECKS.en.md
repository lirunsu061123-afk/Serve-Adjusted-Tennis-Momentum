# Release Checks

Date: 2026-10-20. These are local checks; they do not claim that GitHub Actions has already run.

| Check | Result |
| --- | --- |
| Official downloader | Downloaded and SHA-256 verified |
| Dataset audit | 7,284 points, 31 matches, 46 original columns |
| Full experiment | 1,999 permutations and 3,000 clustered bootstrap draws completed |
| Unit tests | 8/8 passed |
| Report | 20-page Chinese PDF and English PDF generated |
| Visual review | Rendered PDF pages checked for layout and legibility |
| GitHub workflow | Configuration included; cloud execution not claimed |
| External validation | Not completed; limitations are documented |

Key test values are recorded in `results/summary.json` and the CSV tables. The publication archive excludes raw third-party CSV files, caches, and virtual environments.
