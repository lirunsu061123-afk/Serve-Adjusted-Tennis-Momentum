# Data Card

The data come from COMAP’s official resource page for 2024 MCM Problem C: [Momentum in Tennis](https://www.comap.org/membership/member-resources/item/momentum-in-tennis). The archive contains `2024_Wimbledon_featured_matches.csv` and `2024_data_dictionary.csv`.

The local analysis uses 7,284 points, 31 matches, and 46 original columns. The match-data SHA-256 is `b1788d0ea169b65629b0e9fb0f91d007507b306e404507bbf90bd5f700a3c229`. Data were obtained on 2026-10-19.

Rows are retained and sorted by `match_id` and the actual full-match `point_no`. The key fields have no missing values, point identities are unique, and point numbers are consecutive within each match. Although the dictionary describes `point_no` as a within-game number, the supplied file uses a full-match counter; the code checks and preserves the supplied meaning.

Missing values are present in `speed_mph` (752 rows), `return_depth` (1,309), `serve_width` (54), and `serve_depth` (54). These fields are not used in the primary models; they are neither imputed nor used to delete otherwise valid points.

The train/validation/test split is by tournament round: 16 third-round matches / 3,788 points for training, eight fourth-round matches / 1,919 points for validation, and seven quarterfinal-to-final matches / 1,577 points for testing.

Point predictions use only pre-point information. Point outcomes and technical statistics update the state only after the point and can affect later predictions. Cumulative fields such as `p1_points_won`, `game_victor`, and `set_victor` are not used to predict the same point.

The raw data remain the property of the original provider and are not covered by this repository’s MIT license.
