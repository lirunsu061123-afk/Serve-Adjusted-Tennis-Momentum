# 数据卡

## 来源

- 发布方：COMAP。
- 数据：2024 MCM C 提供的 2023 Wimbledon 男单第三轮至决赛逐分记录。
- 官方页面：https://www.comap.org/membership/member-resources/item/momentum-in-tennis
- 获取日期：2026-10-19。
- 文件：`2024_Wimbledon_featured_matches.csv` 和 `2024_data_dictionary.csv`。
- SHA-256：`b1788d0ea169b65629b0e9fb0f91d007507b306e404507bbf90bd5f700a3c229`。
- 范围：7,284 行、46 原始列、31 场；没有另外采集个人资料。

## 清洗规则

保持全部逐分行，按比赛和全场 `point_no` 排序。检查关键列无缺失、胜分方和发球方属于 {1,2}、主键无重复及序号连续。实际 point_no 是全场递增值，和字典的局内编号描述不同。

普通局比分映射为顺序值，抢七保留实际数字，模型比分差截断到 ±4。仅为特征转换，不修改原始数据。

球速缺失 752 行，回球深度缺失 1,309 行，发球宽/深各缺失 54 行。这些列不参与当前模型；不填补，不因其缺失删除有效逐分记录。

## 时间可用性

| 类型 | 字段 | 使用时点 |
| --- | --- | --- |
| 当分事前 | server、盘局比分、局内比分、破发点标志 | 预测当前得分 |
| 当分事后 | point_victor、winner、unf_err、distance_run、rally_count | 更新状态；仅用于之后的预测 |
| 已含当分结果 | points_won、game_victor、set_victor | 汇总、描述；不预测当分 |
| 首次发球前未知或缺失较多 | serve_no、speed_mph、serve/return 深度等 | 当前模型不用 |

## 结果数据字典

`point_predictions.csv`：每行对应一个真实分；`y` 为球员 1 胜分，`p_online` 为事前基线，`pred_context` / `pred_momentum` 为事前模型概率，`m_before` 为此前势头，`m` / `state` / `flip` 为当分结束后状态。`swing_y` 为未来窗口标签，尾部及未建立状态时为空。

`swing_predictions.csv`：只含可完整观察未来窗口且状态非零的行；`constant` / `structural` / `enriched` 为当分结束后的反转预测概率。

`permutation_tests.csv`：`rho` 和 `cusum` 是赛后诊断统计量，`p_*` 是 Monte Carlo p 值，`q_*` 是对全部 62 项比较统一调整后的值。

指标表中 `prevalence` 为实际阳性比例；`average_precision` 是 AP；`alarm_fraction` 是在所列阈值下预测阳性的比例，逐分任务中对应预测球员 1 获胜的比例，不表示教练报警。

## 限制与权利

仅覆盖晋级选手、单赛事、男子草地比赛；无法代表其他赛事、女子或业余选手。缺少环境、伤病和心理观测。原始数据归原权利人所有；发布包只含下载器和派生结果，不把原始数据纳入 MIT 授权。
