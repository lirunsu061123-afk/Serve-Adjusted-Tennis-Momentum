# Coaching Memo

The flow index can support review, but this study does not show that momentum information reliably improves the next-point forecast. Serve identity should remain the benchmark.

Before a match, re-estimate serve and return ability for the new opponent. A momentum value from the previous match should not be transferred directly.

During a match, treat a sustained deviation as a prompt for inspection. Check serve quality, unforced errors, rally length, and physical condition before changing tactics. A run of points may reflect the opponent’s service turn or ordinary random variation.

After a run of success or failure, keep a concrete preparation routine and a next-point task. Do not treat a short sequence as proof of inevitable winning or collapse.

After the match, combine the curve with video. The final-match index identifies 33 micro reversals; each one should not be interpreted as a psychological turning point.

Do not deploy the reversal alarm as an automated tactical trigger. The test reversal rate is 65.67%, and the enriched model effectively alarms almost all the time. A real deployment would need an alarm budget, event-level deduplication, lead-time evaluation, false-alarm costs, and independent validation.
